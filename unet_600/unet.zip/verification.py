# -*- coding: utf-8 -*-
# @Time    : 2022/8/25 10:50
# @Author  : HongFei Wang
import numpy as np

from model import UNet
import matplotlib.pyplot as plt
import torch

image_path = r'E:\taobao\unet_600\datas\image\123455_06.jpg'
label_path = r'E:\taobao\unet_600\datas\label\01_06.jpg'
model_path = './Mdl_Data/unet/4.pth'

model = UNet()
model.load_state_dict(torch.load(model_path))
image_data = plt.imread(image_path)
image = torch.from_numpy((image_data / 255).astype(np.float32)).transpose(0, 2).unsqueeze(0)
label = plt.imread(label_path)

with torch.no_grad():
    image = model(image)
    image[image < 0.5] = 0
    image[image >= 0.5] = 1
image = image.squeeze().detach().numpy()

plt.subplot(121)
plt.title('label')
plt.imshow(image_data)
plt.imshow(label, alpha=1.)

plt.subplot(122)
plt.title('output')
plt.imshow(image,alpha=0.5)
plt.imshow(image_data)

plt.show()
